<?php
require_once('db_constants.inc.php');
$db_con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);