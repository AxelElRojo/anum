<?php
define('DB_NAME', 'anum');
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'anum_admin');
define('DB_PASS', 'passwd');